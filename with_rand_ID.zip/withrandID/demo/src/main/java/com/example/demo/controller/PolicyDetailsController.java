package com.example.demo.controller;

import com.example.demo.entityty.PolicyDetails;
import com.example.demo.repo.PolicyDetailsRepository;
import com.example.demo.service.LetterGenService;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

//import java.util.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.apache.commons.codec.binary.Base64;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.stereotype.Controller;
import java.util.UUID;

//import org.apache.commons.codec.binary.Base64;



@Controller
public class PolicyDetailsController {

    private final PolicyDetailsRepository policyDetailsRepository;
    private final LetterGenService letterGenService;

    @Autowired
    public PolicyDetailsController(PolicyDetailsRepository policyDetailsRepository, LetterGenService letterGenService) {
        this.policyDetailsRepository = policyDetailsRepository;
        this.letterGenService = letterGenService;
    }

    @GetMapping("/")
    public String showHomePage() {
        return "index";
    }

    @GetMapping("/test")
    public String showTestPage() {
        return "test";
    }

    @GetMapping("/showpolicy")
    public String showPolicyPage() {
        return "policy";
    }
    
    
    
    @GetMapping("/addpolicy")
    public String addPolicy() {
        return "addpolicy";
    }
    
    
    @PostMapping("/savepolicy")
    public String savePolicy(
            @RequestParam String policyNumber,
            @RequestParam String firstName,
            @RequestParam String lastName,
            @RequestParam String address1,
            @RequestParam String address2,
            @RequestParam String email,
            @RequestParam String phno,
            @RequestParam String premium) {
        // Create a new PolicyDetails object with the form parameters
    	
    	
    	String randomId = UUID.randomUUID().toString();
    	System.out.println(randomId);
        PolicyDetails policy = new PolicyDetails();
        policy.setPolicyno(policyNumber);
        policy.setFirstname(firstName);
        policy.setLastname(lastName);
        policy.setAddress1(address1);
        policy.setAddress2(address2);
        policy.setEmail(email);
        policy.setMobileno(phno);  // Fix: setMobileno instead of setPolicyno
        policy.setPremium(premium);
        policy.setrandId(randomId);

        try {
            // Call the savePolicy function from PolicyDetailsRepository
            policyDetailsRepository.savePolicy(policy);
        } catch (Exception e) {
            // Log the exception or handle it as appropriate for your application
            e.printStackTrace();
            return "redirect:/addpolicy?errorMessage=Failed to add policy details";
        }
        // Redirect to the home page with a success parameter
        return "redirect:/addpolicy?successMessage=Upload successful";
    }
    
    

    @GetMapping("/policy")
    public String getPolicyDetails(@RequestParam String randId, Model model,HttpSession session) {
        PolicyDetails policyDetails = policyDetailsRepository.findByRandId(randId);

        if (policyDetails != null) {
            System.out.println("Policy Details Found: " + policyDetails.getFirstname() + " " + policyDetails.getLastname());
            System.out.println(policyDetails.getAddress1());
            System.out.println(policyDetails.getAddress2());
            System.out.println(policyDetails.getPolicyno());
            System.out.println(policyDetails.getrandId());
            model.addAttribute("policyDetails", policyDetails);
            session.setAttribute("policyDetails", policyDetails);
            return "oldtemp";
            
        } else {
            System.out.println("Policy Details Not Found for Policy No: " + randId);
            model.addAttribute("message", "No policy found for policy number: " + randId);
            return "policyNotFound";
        }
    }
    
    
    @GetMapping("/genpdf")
    public String generatePdf(Model model, HttpSession session) {
        
    	PolicyDetails policyDetails = null;
	    if (session.getAttribute("policyDetails") != null) {
	    	policyDetails = (PolicyDetails) session.getAttribute("policyDetails");
	    }
        
        try {
            byte[] pdfContent = letterGenService.generatePDF(policyDetails);

            // Convert byte array to Base64-encoded string
            //String base64PdfContent = Base64.getEncoder().encodeToString(pdfContent);   WORKING
            String base64PdfContent = Base64.encodeBase64String(pdfContent);
            // Add PDF content URL to the model
            model.addAttribute("pdfContent", "data:application/pdf;base64," + base64PdfContent);

            // Your existing code
            return "genpdf";
        } catch (Exception e) {
            e.printStackTrace();
            // Handle the exception as needed
            return "error";
        }
    }
  
    
    @PostMapping("/uploadToS3")
    public String uploadToS3(@RequestParam("pdfContent") String base64PdfContent,HttpSession session) {
    	
    	PolicyDetails policyDetails = null;
	    if (session.getAttribute("policyDetails") != null) {
	    	policyDetails = (PolicyDetails) session.getAttribute("policyDetails");
	    }
	    String policyno=policyDetails.getPolicyno();
        // Decode the base64-encoded PDF content
        byte[] pdfContent = Base64.decodeBase64(base64PdfContent);
      //  byte[] pdfContent = Base64.getDecoder().decode(base64PdfContent); 
        // Upload the file to S3
        try {
        letterGenService.uploadFileToS3(pdfContent,policyno);
        return "redirect:/genpdf?successMessage=Upload successful";
        }catch(Exception e)
        {
        	 return "redirect:/genpdf?successMessage=Upload Failed";
        }
        // Redirect to another page or return a response
        

    }
   

}
