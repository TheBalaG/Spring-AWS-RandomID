package com.example.demo.repo;

//import org.springframework.data.repository.CrudRepository;
//
//import java.util.Optional;
//
//import com.example.entity.*;
//
//public interface PolicyDetailsRepository extends CrudRepository<PolicyDetails, String> {
//    Optional<PolicyDetails> findByPolicyNo(String policyNo);
//}
//


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.entityty.*;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;
import software.amazon.awssdk.services.dynamodb.model.PutItemRequest;
import software.amazon.awssdk.services.dynamodb.model.QueryRequest;
import software.amazon.awssdk.services.dynamodb.model.QueryResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class PolicyDetailsRepository {

    private final DynamoDbClient dynamoDbClient;

    @Autowired
    public PolicyDetailsRepository(DynamoDbClient dynamoDbClient) {
        this.dynamoDbClient = dynamoDbClient;
    }

//    public PolicyDetails findByPolicyNo(String policyno) {
//        try {
//            Map<String, AttributeValue> expressionAttributeValues = new HashMap<>();
//            expressionAttributeValues.put(":val", AttributeValue.builder().s(policyno).build());
//
//            QueryRequest queryRequest = QueryRequest.builder()
//                    .tableName("Customer") // Replace with your DynamoDB table name
//                    .keyConditionExpression("policyno = :val")
//                    .expressionAttributeValues(expressionAttributeValues)
//                    .build();
//
//            QueryResponse response = dynamoDbClient.query(queryRequest);
//            List<Map<String, AttributeValue>> items = response.items();
//
//            if (items.isEmpty()) {
//                return null; // Return null if no matching policy is found
//            }
//
//            return mapToPolicyDetails(items.get(0));
//        } catch (Exception e) {
//            // Log the exception or handle it as appropriate for your application
//            e.printStackTrace();
//            return null;
//        }
//    }

    public PolicyDetails findByRandId(String randId) {
        try {
            Map<String, AttributeValue> expressionAttributeValues = new HashMap<>();
            expressionAttributeValues.put(":val", AttributeValue.builder().s(randId).build());

            QueryRequest queryRequest = QueryRequest.builder()
                    .tableName("customer") // Replace with your DynamoDB table name
                  //  .indexName("randId") // Replace with the actual index name for randId
                    .keyConditionExpression("randId = :val")
                    .expressionAttributeValues(expressionAttributeValues)
                    .build();

            QueryResponse response = dynamoDbClient.query(queryRequest);
            List<Map<String, AttributeValue>> items = response.items();

            if (items.isEmpty()) {
                return null; // Return null if no matching policy is found
            }

            return mapToPolicyDetails(items.get(0));
        } catch (Exception e) {
            // Log the exception or handle it as appropriate for your application
            e.printStackTrace();
            return null;
        }
    }

    
    
    
    public void savePolicy(PolicyDetails policyDetails) {
        try {
            Map<String, AttributeValue> itemValues = new HashMap<>();
            itemValues.put("policyno", AttributeValue.builder().s(policyDetails.getPolicyno()).build());
            itemValues.put("firstname", AttributeValue.builder().s(policyDetails.getFirstname()).build());
            itemValues.put("lastname", AttributeValue.builder().s(policyDetails.getLastname()).build());
            itemValues.put("email", AttributeValue.builder().s(policyDetails.getEmail()).build());
            itemValues.put("address1", AttributeValue.builder().s(policyDetails.getAddress1()).build());
            itemValues.put("address2", AttributeValue.builder().s(policyDetails.getAddress2()).build());
            itemValues.put("premium", AttributeValue.builder().s(policyDetails.getPremium()).build());
            itemValues.put("mobileno", AttributeValue.builder().s(policyDetails.getMobileno()).build());
            itemValues.put("randId", AttributeValue.builder().s(policyDetails.getrandId()).build());
            // Add more attributes as needed

            PutItemRequest putItemRequest = PutItemRequest.builder()
                    .tableName("customer") // Replace with your DynamoDB table name
                    .item(itemValues)
                    .build();
            
            System.out.println("Request created");
            
            dynamoDbClient.putItem(putItemRequest);
            
            System.out.println("item added successfully");

        } catch (DynamoDbException e) {
            // Log the exception or throw a custom exception for better error handling
            e.printStackTrace();
            throw new RuntimeException("Failed to save policy details to DynamoDB", e);
        }
    }

    

    private PolicyDetails mapToPolicyDetails(Map<String, AttributeValue> itemAttributes) {
        PolicyDetails PolicyDetails = new PolicyDetails();
        PolicyDetails.setPolicyno(itemAttributes.get("policyno").s());
        PolicyDetails.setFirstname(itemAttributes.get("firstname").s());
        PolicyDetails.setLastname(itemAttributes.get("lastname").s());
        PolicyDetails.setEmail(itemAttributes.get("email").s());
        PolicyDetails.setAddress1(itemAttributes.get("address1").s());
        PolicyDetails.setAddress2(itemAttributes.get("address2").s());
        //PolicyDetails.setAddress3(itemAttributes.get("address3").s());
        //PolicyDetails.setPlan(itemAttributes.get("plan").s());
        PolicyDetails.setPremium(itemAttributes.get("premium").s());
        PolicyDetails.setMobileno(itemAttributes.get("mobileno").s());
        PolicyDetails.setrandId(itemAttributes.get("randId").s());
        

        return PolicyDetails;
    }
}



